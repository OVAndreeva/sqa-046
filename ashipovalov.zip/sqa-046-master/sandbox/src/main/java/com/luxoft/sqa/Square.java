package com.luxoft.sqa;

public class Square {
    private  double lenght;

    public Square(double lenght){
        this.lenght = lenght;

    }



    public double sayArea(){
        return lenght*lenght;
    }

 }
