package com.luxoft.sqa;

import java.util.Date;

public class HelloWorld {

    public static void main(String[] args) {
        Square s = new Square(15.0);
        Rectangle r = new Rectangle(125 , 156);
        System.out.println(s.sayArea());
        System.out.println(r.sayArea());
        Date d = new Date();
        System.out.println(d);

    }



}